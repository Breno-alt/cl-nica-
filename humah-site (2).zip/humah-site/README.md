# Site Clínica Humah — proposta de reformulação

Site estático (HTML, CSS e JavaScript puros). Não precisa de build nem de banco de dados.
**Status:** proposta para apresentação comercial. Nada foi publicado em nenhum domínio. Nunca altere o domínio oficial `clinicahumah.com.br` sem autorização da clínica.

## Estrutura
```
public/            <- o site (é esta pasta que vai para a hospedagem)
  index.html  404.html  robots.txt  sitemap.xml
  css/styles.css  js/main.js
  assets/favicon.svg
  assets/images/   fotos em WebP + og-image.jpg
scripts/go-live.sh <- configura domínio e SEO para produção
netlify.toml  vercel.json  package.json
```

## 1. Ver no seu computador
- Opção simples: abra `public/index.html` no navegador.
- Opção recomendada (precisa do Node.js): na pasta do projeto, rode `npm run dev` e abra o endereço mostrado.

## 2. Modo apresentação x produção
Por padrão o site vem com **noindex** (`robots.txt` bloqueia tudo), para o Google não indexar uma proposta ainda não aprovada.
Quando a clínica aprovar e você tiver o domínio, rode:
```
./scripts/go-live.sh seudominio.com.br
```
Sem terminal: em `public/index.html` e `public/sitemap.xml`, substitua `SEU-DOMINIO.com.br` pelo domínio real, apague a linha `<meta name="robots" ... <!--noindex-->` e troque o `robots.txt` por:
```
User-agent: *
Allow: /
Sitemap: https://seudominio.com.br/sitemap.xml
```

## 3. Publicar — Netlify
**Mais rápido (sem Git):** acesse app.netlify.com/drop, arraste a pasta `public` e pronto. Você recebe um endereço `https://nome.netlify.app`.
**Com Git (recomendado, atualiza sozinho):**
1. Crie um repositório no GitHub e envie o projeto (`git init`, `git add .`, `git commit -m "site"`, `git remote add origin URL`, `git push -u origin main`).
2. No Netlify: *Add new site → Import an existing project* → escolha o repositório.
3. O `netlify.toml` já define a pasta `public`. Clique em *Deploy*.

## 4. Publicar — Vercel
1. Envie o projeto ao GitHub (passo 1 acima).
2. Em vercel.com: *Add New → Project* → importe o repositório.
3. O `vercel.json` já configura a pasta `public` e não há build. Clique em *Deploy*. Você recebe um endereço `https://nome.vercel.app`.

## 5. Domínio próprio (no futuro)
1. Registre o domínio (ex.: Registro.br).
2. No painel da hospedagem: *Domain settings → Add domain* (Netlify) ou *Settings → Domains* (Vercel).
3. A plataforma mostra os registros DNS exatos (A/CNAME). Cadastre-os no painel do registro do domínio. Use os valores que o painel mostrar, pois podem mudar.
4. Aguarde a propagação (minutos a algumas horas). O HTTPS é emitido automaticamente.
5. Rode o `go-live.sh` com o domínio e publique de novo.
Use um domínio ou subdomínio de testes (ex.: `proposta.seudominio.com.br`). Não aponte nada para `clinicahumah.com.br` sem autorização.

## 6. Como editar
- Textos: `public/index.html`. Cores e layout: `public/css/styles.css`. Menu, carrossel e animações: `public/js/main.js`.
- Especialidades: lista `SP` em `main.js`.
- Equipe: a seção está oculta (`#equipe{display:none}` no CSS). Quando houver dados confirmados e fotos autorizadas, preencha a seção e remova essa regra.

## 7. Pendências antes de publicar de verdade
- Horários de atendimento e número da sala/complemento do endereço.
- Fotos originais em alta resolução e autorização de uso (clínica e profissional retratada). As atuais vieram de capturas do Google Maps (~700 px).
- Dados da equipe (nome, especialidade, registro, foto autorizada).
- Revisão jurídica da política de privacidade (controlador, encarregado, retenção, direitos do titular).
- As fontes vêm do Google Fonts (servidores externos). Para LGPD mais rígida, hospede as fontes no projeto.
- Confirmar que WhatsApp, telefone e e-mail estão ativos.
- O botão "Como chegar" usa o link do Maps informado; confirme o local.
- Não há formulário nem rastreamento. Se adicionar, atualize a política.
