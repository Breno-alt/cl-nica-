
const $=s=>document.querySelector(s);
const hd=$('#hd');addEventListener('scroll',()=>hd.classList.toggle('s',scrollY>30),{passive:true});
const mt=$('#mt'),mn=$('#mn');mt.onclick=()=>{const o=mn.classList.toggle('open');mt.setAttribute('aria-expanded',o)};
mn.querySelectorAll('a').forEach(a=>a.onclick=()=>{mn.classList.remove('open');mt.setAttribute('aria-expanded',false)});
addEventListener('keydown',e=>{if(e.key==='Escape'){mn.classList.remove('open');mt.setAttribute('aria-expanded',false)}});
const SP=[{n:'Ginecologia e Obstetrícia',d:'Cuidado e acompanhamento da saúde da mulher em diferentes fases da vida.',i:'M12 21s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.5-7 10-7 10z'},{n:'Mastologia',d:'Atenção à saúde das mamas e à prevenção.',i:'M12 3c4 4 6 7 6 10a6 6 0 01-12 0c0-3 2-6 6-10z'}];
$('#sp').innerHTML=SP.map(s=>`<article class="card reveal"><div class="ic"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="${s.i}"/></svg></div><h3>${s.n}</h3><p>${s.d}</p><a class="btn o" href="#contato">Saiba mais</a></article>`).join('');
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
document.querySelectorAll('.reveal').forEach(e=>io.observe(e));
const rm=matchMedia('(prefers-reduced-motion:reduce)').matches;
if(!rm&&matchMedia('(pointer:fine)').matches){const st=$('#st');st.addEventListener('mousemove',e=>{const r=st.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;st.querySelectorAll('.ly').forEach(l=>{const d=+l.dataset.d;l.style.transform=`translate(${x*d*3}px,${y*d*3}px) rotateY(${x*d}deg) rotateX(${-y*d}deg)`})});st.addEventListener('mouseleave',()=>st.querySelectorAll('.ly').forEach(l=>l.style.transform=''))}
const tr=$('#tr'),n=tr.children.length,dt=$('#dt');let k=0;
dt.innerHTML=[...Array(n)].map((_,i)=>`<button aria-label="Ir para foto ${i+1}"></button>`).join('');
const go=i=>{k=(i+n)%n;tr.style.transform=`translateX(-${k*100}%)`;[...dt.children].forEach((b,j)=>b.setAttribute('aria-current',j===k))};
[...dt.children].forEach((b,i)=>b.onclick=()=>go(i));$('#pv').onclick=()=>go(k-1);$('#nx').onclick=()=>go(k+1);go(0);
let sx=0;tr.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});tr.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-sx;if(Math.abs(d)>40)go(k+(d<0?1:-1))});
