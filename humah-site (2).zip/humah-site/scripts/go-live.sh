#!/bin/sh
# Uso: ./scripts/go-live.sh dominio.com.br
# Troca o domínio de exemplo, libera a indexação e gera o robots.txt de produção.
[ -z "$1" ] && { echo "Uso: $0 dominio.com.br"; exit 1; }
D="$1"; cd "$(dirname "$0")/../public" || exit 1
for f in index.html sitemap.xml; do sed "s#SEU-DOMINIO.com.br#$D#g" "$f" > "$f.tmp" && mv "$f.tmp" "$f"; done
sed '/<!--noindex-->/d' index.html > index.tmp && mv index.tmp index.html
printf 'User-agent: *\nAllow: /\nSitemap: https://%s/sitemap.xml\n' "$D" > robots.txt
echo "Pronto: domínio $D configurado e indexação liberada."
